# 統聯客運 & 中台灣客運 車輛配站查詢 App

此專案已整合所有車輛配站資料（共 361 筆，包含統聯客運 235 輛、中台灣客運 126 輛），涵蓋新福、清水、中科、烏日、豐勢、霧峰等各配屬場站。

## 📱 如何在 Android 手機上取得如同 APK 一樣的獨立 App：

### 方法一：免編譯 PWA 直接安裝（最推薦、零門檻）
1. 將本專案內的 `index.html`、`manifest.json`、`sw.js` 以及圖示檔案上傳至任何靜態託管（如 GitHub Pages、Vercel、Netlify 或本機伺服器）。
2. 在 Android 手機上以 **Google Chrome** 打開網頁。
3. 點選瀏覽器右上角的選單（三個點），選擇「**新增至主畫面**」或「**安裝應用程式**」。
4. 手機桌面將會直接產生專屬的綠色巴士 App 圖示，打開後無網址列、全螢幕原生體驗，且支援離線查詢。

---

### 方法二：透過 PWABuilder 一鍵轉成 APK（免裝開發工具）
1. 將網頁部屬至 GitHub Pages。
2. 開啟微軟官方免費工具：[https://www.pwabuilder.com/](https://www.pwabuilder.com/)
3. 輸入您的網址，點擊「Build My PWA」-> 選擇 **Android**。
4. 下載生成的 `.apk` 安裝檔直接安裝至 Android 手機。

---

### 方法三：使用 Android Studio 編譯成原生 APK
1. 在 Android Studio 中建立一個「Empty Views Activity」專案。
2. 將本專案的 `index.html`、`manifest.json` 放置於 `app/src/main/assets/` 目錄。
3. 使用 `MainActivity.java` 透過 WebView 載入 `file:///android_asset/index.html`。
4. 點選功能表 `Build` -> `Build Bundle(s) / APK(s)` -> `Build APK(s)`，即可輸出標準 `.apk` 檔。
